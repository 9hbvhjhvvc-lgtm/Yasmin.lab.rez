# Yasmin.lab.rez — электронды резюме-кітап

Төрехан Ясминнің электронды резюме-кітабы. Жоба фронтенд (HTML, CSS, JavaScript) және бэкенд (Java) бөлімдерінен тұрады.

**Сайттың онлайн нұсқасы (GitHub Pages):** https://USERNAME.github.io/Yasmin.lab.rez/

## Қолданылған технологиялар

| Технология | Қайда қолданылды |
|---|---|
| HTML5 | `web/index.html`, `web/messages.html` — беттердің құрылымы |
| CSS3 | `web/css/style.css`, `web/css/messages.css` — кітаптың дизайны, парақ аудару анимациясы, мобильді нұсқа |
| JavaScript | `web/js/script.js` — парақтау, мазмұн, байланыс формасы; `web/js/messages.js` — хабарламаларды жүктеу |
| Java | `src/Server.java` — HTTP-сервер: беттерді береді, формадан келген хабарламаны қабылдап, `data/messages.txt` файлына сақтайды |

## Жоба құрылымы

```
Yasmin.lab.rez/
├── index.html            # GitHub Pages үшін: web/index.html бетіне бағыттайды
├── web/
│   ├── index.html        # кітаптың негізгі беті
│   ├── messages.html     # келген хабарламалар беті
│   ├── css/
│   │   ├── style.css
│   │   └── messages.css
│   └── js/
│       ├── script.js
│       └── messages.js
├── src/
│   └── Server.java       # Java сервері
├── out/
│   └── Server.class      # компиляцияланған сервер (Java 8+)
├── start.bat             # Windows-та іске қосу
└── start.sh              # Linux / macOS-та іске қосу
```

## Жұмыс принципі

1. Java сервері `http://localhost:8080` мекенжайында іске қосылады.
2. Сервер `web` папкасындағы HTML, CSS және JS файлдарын браузерге береді.
3. «Байланыс» бетіндегі форма толтырылып, «Жіберу» басылғанда, JavaScript мәліметті JSON түрінде `/api/messages` мекенжайына POST сұранысымен жібереді.
4. Java сервері өрістерді тексеріп, хабарламаны `data/messages.txt` файлына жазады.
5. Барлық хабарламалар `http://localhost:8080/messages.html` бетінде көрінеді (GET `/api/messages`).

## Іске қосу

**Windows:** `start.bat` файлын екі рет басыңыз. Браузерде `http://localhost:8080` ашылады.

**Қолмен:**

```
javac -encoding UTF-8 -d out src/Server.java
java -cp out Server
```

Компьютерде Java 8 немесе одан жаңа нұсқасы болуы керек (`java -version`).

> GitHub Pages тек статикалық беттерді көрсетеді, сондықтан онлайн нұсқада кітап толық жұмыс істейді, ал байланыс формасы тек Java сервері іске қосылғанда (локальді) жұмыс істейді.

## Авторы

Төрехан Ясмин Рахимбердіқызы, 05-057-24-02 тобы
С. Сейфуллин атындағы Қазақ агротехникалық зерттеу университеті
